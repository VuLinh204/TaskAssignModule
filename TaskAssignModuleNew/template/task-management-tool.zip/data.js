// Mock Data Simulation

export const positions = [
    { PositionID: 1, PositionName: 'Project Manager' },
    { PositionID: 2, PositionName: 'Software Engineer' },
    { PositionID: 3, PositionName: 'QA Engineer' },
    { PositionID: 4, PositionName: 'UI/UX Designer' },
];

export const employees = [
    { EmployeeID: 1, EmployeeName: 'Alice', PositionID: 1, Email: 'alice@example.com', IsActive: true },
    { EmployeeID: 2, EmployeeName: 'Bob', PositionID: 2, Email: 'bob@example.com', IsActive: true },
    { EmployeeID: 3, EmployeeName: 'Charlie', PositionID: 2, Email: 'charlie@example.com', IsActive: true },
    { EmployeeID: 4, EmployeeName: 'Diana', PositionID: 3, Email: 'diana@example.com', IsActive: true },
    { EmployeeID: 5, EmployeeName: 'Ethan', PositionID: 4, Email: 'ethan@example.com', IsActive: true },
];

let nextProjectId = 4;
export const projects = [
    { ProjectID: 1, ProjectName: 'Phoenix Project', Description: 'A major overhaul of the legacy system.', OwnerID: 1, StartDate: '2024-01-01', EndDate: '2024-12-31', Status: 'In Progress', Priority: 'High' },
    { ProjectID: 2, ProjectName: 'Mobile App Launch', Description: 'Develop and launch the new mobile application.', OwnerID: 1, StartDate: '2024-03-01', EndDate: '2024-09-30', Status: 'On Track', Priority: 'High' },
    { ProjectID: 3, ProjectName: 'Marketing Website', Description: 'Redesign the company marketing website.', OwnerID: 1, StartDate: '2024-05-01', EndDate: '2024-08-01', Status: 'Completed', Priority: 'Medium' },
];

export const tags = [
    { TagID: 1, TagName: 'Bug', Color: '#ef4444' },
    { TagID: 2, TagName: 'Feature', Color: '#3b82f6' },
    { TagID: 3, TagName: 'UI', Color: '#a855f7' },
    { TagID: 4, TagName: 'Backend', Color: '#f97316' },
];

let nextTaskId = 1;
export const tasks = [
    // Project 1
    { TaskID: 1, ProjectID: 1, TaskName: 'Setup project repository', Description: 'Initialize Git repo and CI/CD pipeline.', AssigneeID: 2, CreatedBy: 1, ParentTaskID: null, StartDate: '2024-01-05', DueDate: '2024-01-15', Status: 'Done', Priority: 'High' },
    { TaskID: 2, ProjectID: 1, TaskName: 'Design architecture', Description: 'Finalize the database schema and microservices plan.', AssigneeID: 3, CreatedBy: 1, ParentTaskID: null, StartDate: '2024-01-16', DueDate: '2024-02-01', Status: 'Done', Priority: 'High' },
    { TaskID: 3, ProjectID: 1, TaskName: 'Develop authentication service', Description: 'Implement JWT-based authentication.', AssigneeID: 2, CreatedBy: 1, ParentTaskID: null, StartDate: '2024-02-02', DueDate: '2024-03-10', Status: 'In Progress', Priority: 'High' },
    // Subtasks for Task 3
    { TaskID: 4, ProjectID: 1, TaskName: 'Implement login endpoint', Description: '', AssigneeID: 2, CreatedBy: 1, ParentTaskID: 3, StartDate: '2024-02-05', DueDate: '2024-02-15', Status: 'Done', Priority: 'High' },
    { TaskID: 5, ProjectID: 1, TaskName: 'Implement registration endpoint', Description: '', AssigneeID: 3, CreatedBy: 1, ParentTaskID: 3, StartDate: '2024-02-16', DueDate: '2024-02-25', Status: 'In Progress', Priority: 'High' },
    { TaskID: 6, ProjectID: 1, TaskName: 'Add password hashing', Description: '', AssigneeID: 3, CreatedBy: 1, ParentTaskID: 5, StartDate: '2024-02-18', DueDate: '2024-02-22', Status: 'To Do', Priority: 'High' },
    
    { TaskID: 7, ProjectID: 1, TaskName: 'Create UI mockups for dashboard', Description: 'Use Figma to design the main dashboard view.', AssigneeID: 5, CreatedBy: 1, ParentTaskID: null, StartDate: '2024-02-10', DueDate: '2024-02-28', Status: 'In Progress', Priority: 'Medium' },
    { TaskID: 8, ProjectID: 1, TaskName: 'QA & Testing', Description: 'Write unit tests and E2E tests.', AssigneeID: 4, CreatedBy: 1, ParentTaskID: null, StartDate: '2024-03-01', DueDate: '2024-04-01', Status: 'To Do', Priority: 'Medium' },
    
    // Project 2
    { TaskID: 9, ProjectID: 2, TaskName: 'Market research for new app', Description: 'Analyze competitor apps and user demographics.', AssigneeID: 1, CreatedBy: 1, ParentTaskID: null, StartDate: '2024-03-05', DueDate: '2024-03-15', Status: 'Done', Priority: 'High' },
    { TaskID: 10, ProjectID: 2, TaskName: 'Develop Core Features', Description: 'Implement the initial loading screen for iOS and Android.', AssigneeID: 5, CreatedBy: 1, ParentTaskID: null, StartDate: '2024-03-20', DueDate: '2024-05-01', Status: 'In Progress', Priority: 'Medium' },
    { TaskID: 11, ProjectID: 2, TaskName: 'API for user profiles', Description: 'Build REST endpoints for creating and updating user profiles.', AssigneeID: 3, CreatedBy: 1, ParentTaskID: 10, StartDate: '2024-04-01', DueDate: '2024-04-30', Status: 'To Do', Priority: 'High' },
];
// Reset nextTaskId to be higher than the max ID in the static list
nextTaskId = 12;


export const taskTags = [
    { TaskID: 3, TagID: 4 },
    { TaskID: 7, TagID: 3 },
    { TaskID: 8, TagID: 2 },
    { TaskID: 6, TagID: 4 },
    { TaskID: 11, TagID: 4 },
];

let nextProcessId = 1;
export const taskProcesses = [
    { ProcessID: nextProcessId++, TaskID: 1, OldStatus: 'To Do', NewStatus: 'In Progress', ChangedBy: 2, ChangedDate: '2024-01-10T10:00:00Z' },
    { ProcessID: nextProcessId++, TaskID: 1, OldStatus: 'In Progress', NewStatus: 'Done', ChangedBy: 2, ChangedDate: '2024-01-12T15:30:00Z' },
];

export function getNextTaskId() {
    return nextTaskId++;
}

export function getNextProcessId() {
    return nextProcessId++;
}

export function getNextProjectId() {
    return nextProjectId++;
}
