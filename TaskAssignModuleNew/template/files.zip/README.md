# Task Management Tool

A modern, feature-rich task management application built with pure Vanilla JavaScript. No frameworks, no TypeScript - just clean, simple JavaScript.

![Task Management Tool](https://github.com/user-attachments/assets/0aa67016-6eaf-458a-adb2-6e31a0763ed6)

## Features

- 📊 **Multiple Views**: Switch between Kanban board, List view, and Chart view
- 🗂️ **Project Management**: Create and manage multiple projects
- ✅ **Task Hierarchy**: Support for tasks and subtasks
- 🏷️ **Tags & Labels**: Organize tasks with color-coded tags
- 👥 **Team Collaboration**: Assign tasks to team members
- 📈 **Priority Levels**: Set and track task priorities (Low, Medium, High)
- 🔄 **Drag & Drop**: Intuitive drag-and-drop in Kanban view
- 📝 **Task Details**: Rich task information with descriptions and dates
- 🎨 **Modern UI**: Beautiful dark theme with Tailwind CSS

## Tech Stack

- **Vanilla JavaScript** (ES6+)
- **Vite** - Fast build tool and dev server
- **Tailwind CSS** - Utility-first CSS framework
- **No frameworks** - Pure JavaScript for maximum performance

## Prerequisites

- Node.js (v16 or higher recommended)
- npm or yarn

## Installation & Setup

1. **Clone or download this repository**

2. **Install dependencies:**
   ```bash
   npm install
   ```

3. **Start the development server:**
   ```bash
   npm run dev
   ```

4. **Open your browser:**
   Navigate to `http://localhost:3000`

## Available Scripts

- `npm run dev` - Start development server with hot reload
- `npm run build` - Build for production
- `npm run preview` - Preview production build locally

## Project Structure

```
task-management-vanilla/
├── index.html          # Main HTML file
├── index.js            # Main application logic
├── data.js             # Mock data and data management
├── vite.config.js      # Vite configuration
├── package.json        # Project dependencies
└── .gitignore          # Git ignore rules
```

## How to Use

### Creating a Project
1. Click the **"+"** button in the sidebar
2. Enter project name
3. Click **"Create Project"**

### Managing Tasks
1. Select a project from the sidebar
2. Use **"+ Add task"** button to create new tasks
3. Click on any task to view/edit details
4. Drag tasks between columns in Kanban view

### Switching Views
- **Kanban**: Visual board with drag-and-drop
- **List**: Table view with sortable columns
- **Chart**: Gantt-style timeline view

### Creating Subtasks
1. Click on a parent task
2. In task details, click **"Add Subtask"**
3. Fill in subtask information

## Customization

### Modifying Task Statuses
Edit the `KANBAN_STATUSES` array in `index.js`:
```javascript
const KANBAN_STATUSES = ['To Do', 'In Progress', 'Testing', 'Done'];
```

### Adding More Sample Data
Edit the arrays in `data.js`:
- `projects` - Project list
- `employees` - Team members
- `tasks` - Task items
- `tags` - Task labels

### Styling
The app uses Tailwind CSS via CDN. Modify inline classes or add custom CSS in `<style>` tag in `index.html`.

## Browser Support

- Chrome/Edge (latest)
- Firefox (latest)
- Safari (latest)

## Future Enhancements

- [ ] Persistent storage (localStorage/backend)
- [ ] Real-time collaboration
- [ ] Advanced filtering and search
- [ ] Export/import functionality
- [ ] User authentication
- [ ] Task comments and attachments
- [ ] Email notifications

## License

MIT License - feel free to use this project for learning or production.

## Contributing

Contributions are welcome! Feel free to:
1. Fork the repository
2. Create a feature branch
3. Submit a pull request

## Support

If you encounter any issues or have questions, please open an issue on the repository.

---

**Built with ❤️ using Vanilla JavaScript**

