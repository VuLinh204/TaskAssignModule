# Quick Start Guide

Get up and running in 3 simple steps!

## 1. Install Dependencies

```bash
npm install
```

## 2. Start Development Server

```bash
npm run dev
```

## 3. Open Browser

Navigate to: **http://localhost:3000**

---

## That's it! 🎉

You should now see the Task Management Tool running in your browser.

## What's Next?

- Click **"+ Add Project"** to create your first project
- Add tasks using the **"+ Add task"** button
- Try dragging tasks between columns in Kanban view
- Switch between different views (Kanban, List, Chart)

## Need Help?

Check out the full [README.md](./README.md) for detailed documentation.

## Quick Tips

- Press **ESC** to close any modal
- Click on a task to see full details
- Use the breadcrumb navigation to move between project levels
- Tasks can have subtasks - click on a task and add subtasks from there

## Troubleshooting

**Port 3000 already in use?**
Edit `vite.config.js` and change the port number:
```javascript
server: {
  port: 3001, // Change to any available port
  host: '0.0.0.0',
}
```

**Dependencies not installing?**
Try clearing npm cache:
```bash
npm cache clean --force
npm install
```
