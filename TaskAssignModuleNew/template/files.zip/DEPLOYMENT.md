# 🚀 Deployment Guide

Complete guide to deploying your Task Management Tool to production.

---

## 📦 Build for Production

### Step 1: Build the Project

```bash
npm run build
```

This creates a `dist/` folder with optimized files:
- Minified JavaScript
- Optimized CSS
- Compressed assets
- Production-ready HTML

### Step 2: Test the Build Locally

```bash
npm run preview
```

Opens at http://localhost:4173 (or another port)

---

## 🌐 Deployment Options

### Option 1: Vercel (Recommended - Easiest)

**Why Vercel?**
- Zero configuration
- Free tier available
- Automatic SSL
- Global CDN
- Git integration

**Steps:**

1. **Install Vercel CLI:**
```bash
npm install -g vercel
```

2. **Deploy:**
```bash
vercel
```

3. **Follow prompts:**
```
? Set up and deploy? Yes
? Which scope? (Your account)
? Link to existing project? No
? What's your project's name? task-management-tool
? In which directory is your code located? ./
? Want to override the settings? No
```

4. **Done!** 
Your app is live at: `https://task-management-tool.vercel.app`

**For updates:**
```bash
vercel --prod
```

---

### Option 2: Netlify (Very Easy)

**Why Netlify?**
- Drag & drop deployment
- Free tier available
- Continuous deployment
- Form handling
- Functions support

**Method A: Drag & Drop**

1. Build project: `npm run build`
2. Go to https://app.netlify.com/drop
3. Drag `dist/` folder
4. Done!

**Method B: CLI**

1. **Install Netlify CLI:**
```bash
npm install -g netlify-cli
```

2. **Login:**
```bash
netlify login
```

3. **Deploy:**
```bash
netlify deploy --prod --dir=dist
```

**Method C: Git Integration**

1. Push code to GitHub
2. Go to Netlify dashboard
3. Click "New site from Git"
4. Select your repository
5. Build command: `npm run build`
6. Publish directory: `dist`
7. Deploy!

---

### Option 3: GitHub Pages (Free)

**Why GitHub Pages?**
- Completely free
- Easy with GitHub
- Custom domain support
- HTTPS included

**Steps:**

1. **Install gh-pages:**
```bash
npm install --save-dev gh-pages
```

2. **Add to package.json:**
```json
{
  "scripts": {
    "deploy": "vite build && gh-pages -d dist"
  }
}
```

3. **Update vite.config.js:**
```javascript
export default defineConfig({
  base: '/your-repo-name/', // Add this line
  // ... rest of config
});
```

4. **Deploy:**
```bash
npm run deploy
```

5. **Enable GitHub Pages:**
- Go to repository Settings
- Navigate to Pages section
- Source: gh-pages branch
- Save

**Your site:** `https://yourusername.github.io/repo-name/`

---

### Option 4: AWS S3 + CloudFront (Scalable)

**Why AWS?**
- Enterprise-grade
- Global distribution
- Pay-as-you-go
- Highly scalable

**Steps:**

1. **Build project:**
```bash
npm run build
```

2. **Create S3 Bucket:**
- Go to AWS S3 Console
- Create bucket (e.g., "task-management-app")
- Enable static website hosting
- Make bucket public (for hosting)

3. **Upload files:**
```bash
aws s3 sync dist/ s3://task-management-app --delete
```

4. **Create CloudFront Distribution:**
- Origin: Your S3 bucket
- Viewer Protocol: Redirect HTTP to HTTPS
- Default Root Object: index.html
- Custom Error Response: 404 -> /index.html (for SPA routing)

5. **Configure DNS:**
- Point your domain to CloudFront URL
- Add SSL certificate (AWS Certificate Manager)

**Cost:** ~$0.50-5/month depending on traffic

---

### Option 5: Firebase Hosting (Google)

**Why Firebase?**
- Google infrastructure
- Free tier: 10 GB/month
- Fast global CDN
- Easy rollbacks

**Steps:**

1. **Install Firebase CLI:**
```bash
npm install -g firebase-tools
```

2. **Login:**
```bash
firebase login
```

3. **Initialize:**
```bash
firebase init hosting
```

Select:
- Public directory: `dist`
- Single-page app: `Yes`
- Automatic builds: `No`

4. **Build and Deploy:**
```bash
npm run build
firebase deploy
```

**Your site:** `https://your-project.web.app`

---

### Option 6: Cloudflare Pages (Fast)

**Why Cloudflare Pages?**
- Blazing fast CDN
- Unlimited bandwidth (free)
- Automatic HTTPS
- Edge computing

**Steps:**

1. **Push to Git** (GitHub/GitLab)

2. **Go to Cloudflare Pages Dashboard**

3. **Connect repository**

4. **Configure build:**
- Build command: `npm run build`
- Build output: `dist`
- Environment variables: (none needed)

5. **Deploy!**

**Updates:** Automatic on git push

---

### Option 7: Traditional Web Hosting (cPanel)

**For shared hosting like Bluehost, HostGator, etc.**

**Steps:**

1. **Build locally:**
```bash
npm run build
```

2. **Upload via FTP:**
- Connect to your host via FTP
- Navigate to `public_html/` or `www/`
- Upload all files from `dist/` folder

3. **Configure:**
- Ensure index.html is the default document
- Add .htaccess for SPA routing (if Apache):

```apache
<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteBase /
  RewriteRule ^index\.html$ - [L]
  RewriteCond %{REQUEST_FILENAME} !-f
  RewriteCond %{REQUEST_FILENAME} !-d
  RewriteRule . /index.html [L]
</IfModule>
```

---

## 🔧 Configuration for Deployment

### Environment Variables

Create `.env.production`:
```bash
# If using API keys
VITE_API_URL=https://api.yourbackend.com
VITE_API_KEY=your_production_key
```

### SPA Routing Setup

For proper SPA routing, configure your server:

**Nginx:**
```nginx
location / {
  try_files $uri $uri/ /index.html;
}
```

**Apache (.htaccess):**
```apache
RewriteEngine On
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule . /index.html [L]
```

**Express.js:**
```javascript
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'dist', 'index.html'));
});
```

---

## 🛡️ Production Checklist

Before deploying, ensure:

### Performance
- [ ] Build is minified (`npm run build`)
- [ ] Images are optimized
- [ ] Unused code removed
- [ ] Compression enabled (gzip/brotli)

### Security
- [ ] HTTPS enabled
- [ ] Content Security Policy headers
- [ ] No sensitive data in frontend
- [ ] API keys in environment variables
- [ ] CORS properly configured

### SEO & Accessibility
- [ ] Meta tags added
- [ ] Open Graph tags
- [ ] Favicon included
- [ ] Robots.txt configured
- [ ] Sitemap.xml created

### Functionality
- [ ] All features tested
- [ ] Cross-browser compatibility verified
- [ ] Mobile responsiveness checked
- [ ] Error handling in place
- [ ] Loading states implemented

### Monitoring
- [ ] Analytics added (Google Analytics, Plausible)
- [ ] Error tracking (Sentry, LogRocket)
- [ ] Performance monitoring
- [ ] Uptime monitoring

---

## 📊 Performance Optimization

### Before Deployment

1. **Analyze Bundle Size:**
```bash
npm run build -- --mode analyze
```

2. **Optimize Images:**
- Use WebP format
- Compress with TinyPNG
- Lazy load images

3. **Enable Compression:**
Most hosts do this automatically, but verify gzip/brotli is enabled.

4. **Add Caching Headers:**
```
Cache-Control: max-age=31536000 for static assets
Cache-Control: no-cache for index.html
```

---

## 🔄 Continuous Deployment (CD)

### GitHub Actions Example

Create `.github/workflows/deploy.yml`:

```yaml
name: Deploy to Production

on:
  push:
    branches: [ main ]

jobs:
  deploy:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v2
    
    - name: Setup Node.js
      uses: actions/setup-node@v2
      with:
        node-version: '18'
    
    - name: Install dependencies
      run: npm ci
    
    - name: Build
      run: npm run build
    
    - name: Deploy to Vercel
      run: npx vercel --prod --token=${{ secrets.VERCEL_TOKEN }}
```

---

## 🌍 Custom Domain Setup

### For Vercel/Netlify

1. **Add domain in dashboard**
2. **Update DNS records:**
```
Type: CNAME
Name: www
Value: cname.vercel-dns.com (or Netlify)
```

### For AWS/Cloudflare

1. **Update Route 53 / Cloudflare DNS**
2. **Point to distribution URL**
3. **Add SSL certificate**

---

## 🔒 Security Headers

Add these headers for production:

```
Content-Security-Policy: default-src 'self' https://cdn.tailwindcss.com
X-Frame-Options: DENY
X-Content-Type-Options: nosniff
Referrer-Policy: strict-origin-when-cross-origin
Permissions-Policy: geolocation=(), microphone=(), camera=()
```

**How to add:**
- **Vercel/Netlify:** `vercel.json` or `netlify.toml`
- **Apache:** `.htaccess`
- **Nginx:** Server config

---

## 📱 Progressive Web App (PWA) - Optional

To make it installable:

1. **Add manifest.json:**
```json
{
  "name": "Task Management Tool",
  "short_name": "TaskMgr",
  "icons": [
    {
      "src": "/icon-192.png",
      "sizes": "192x192",
      "type": "image/png"
    }
  ],
  "start_url": "/",
  "display": "standalone",
  "theme_color": "#0e7490",
  "background_color": "#0f172a"
}
```

2. **Add service worker** (advanced)

3. **Update index.html:**
```html
<link rel="manifest" href="/manifest.json">
```

---

## 📈 Post-Deployment

### Testing Production

1. **Test all features**
2. **Check different devices**
3. **Verify SSL certificate**
4. **Test load times**
5. **Check error handling**

### Monitor Performance

- **Google PageSpeed Insights**
- **WebPageTest.org**
- **GTmetrix**
- **Lighthouse CI**

### Set Up Monitoring

- **Uptime:** UptimeRobot, Pingdom
- **Analytics:** Google Analytics, Plausible
- **Errors:** Sentry, LogRocket
- **Performance:** New Relic, Datadog

---

## 🐛 Troubleshooting

### Build Fails
```bash
# Clear cache and rebuild
rm -rf node_modules dist
npm install
npm run build
```

### Deployment Fails
- Check build logs
- Verify environment variables
- Ensure correct build directory

### 404 Errors on Refresh
- Configure SPA routing (see above)
- Check server configuration

### Slow Performance
- Enable compression
- Optimize images
- Use CDN
- Add caching headers

---

## 💰 Cost Comparison

| Platform | Free Tier | Paid Plans | Best For |
|----------|-----------|------------|----------|
| Vercel | 100GB bandwidth | $20/mo | Easy deployment |
| Netlify | 100GB bandwidth | $19/mo | Git integration |
| GitHub Pages | Free unlimited | N/A | Open source |
| AWS S3+CF | 5GB free first year | ~$5/mo | Enterprise |
| Firebase | 10GB/mo | Pay-as-you-go | Google ecosystem |
| Cloudflare | Unlimited | $20/mo (pro) | Performance |

---

## 🎯 Recommended Setup

**For Personal/Small Projects:**
→ **Vercel** or **Netlify** (free tier)

**For Open Source:**
→ **GitHub Pages** (100% free)

**For Enterprise:**
→ **AWS S3 + CloudFront** (scalable, reliable)

**For Maximum Speed:**
→ **Cloudflare Pages** (unlimited bandwidth)

---

## 📞 Need Help?

- Check platform documentation
- Search Stack Overflow
- Ask in platform-specific forums
- Review build logs carefully

---

**Happy Deploying! 🚀**

Your task management tool is ready for the world!
