import { projects, tasks, employees, tags, taskTags, taskProcesses, getNextTaskId, getNextProcessId, getNextProjectId } from './data.js';

// --- STATE MANAGEMENT ---
let navigationStack = []; // e.g., [{ type: 'project', id: 1 }, { type: 'task', id: 3 }]
let currentViewMode = 'kanban'; // 'kanban', 'list', 'chart'
let draggedTaskId = null;
const KANBAN_STATUSES = ['To Do', 'In Progress', 'Testing', 'Done'];

// --- DOM ELEMENT REFERENCES ---
const projectListEl = document.getElementById('project-list');
const viewTitleEl = document.getElementById('view-title');
const breadcrumbEl = document.getElementById('breadcrumb');
const viewSwitcherEl = document.getElementById('view-switcher');
const viewContainerEl = document.getElementById('view-container');

// Modals & Buttons
const taskModalEl = document.getElementById('task-modal');
const modalTaskNameEl = document.getElementById('modal-task-name');
const modalContentEl = document.getElementById('modal-content');
const modalCloseBtn = document.getElementById('modal-close-btn');
const editTaskBtn = document.getElementById('edit-task-btn');
const deleteTaskBtn = document.getElementById('delete-task-btn');

const createTaskModalEl = document.getElementById('create-task-modal');
const createTaskForm = document.getElementById('create-task-form');
const createModalCloseBtn = document.getElementById('create-modal-close-btn');
const createModalTitleEl = document.getElementById('create-modal-title');

const addProjectModalEl = document.getElementById('add-project-modal');
const addProjectForm = document.getElementById('add-project-form');
const addProjectCloseBtn = document.getElementById('add-project-close-btn');
const addProjectBtn = document.getElementById('add-project-btn');

// --- UTILITY FUNCTIONS ---
const findEmployee = (id) => employees.find(e => e.EmployeeID === id) || { EmployeeName: 'Unassigned' };
const getPriorityStyles = (priority) => {
    switch (priority) {
        case 'High': return 'bg-red-500/20 text-red-400 border-red-500/30';
        case 'Medium': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
        case 'Low': return 'bg-green-500/20 text-green-400 border-green-500/30';
        default: return 'bg-slate-500/20 text-slate-400 border-slate-500/30';
    }
};
const hasSubtasks = (taskId) => tasks.some(t => t.ParentTaskID === taskId);

// --- CORE RENDER FUNCTION ---
function render() {
    const context = navigationStack[navigationStack.length - 1];
    renderProjects();
    renderBreadcrumb();
    renderViewSwitcher();
    
    if (!context) {
        viewTitleEl.textContent = 'Select a Project';
        viewContainerEl.innerHTML = '<p class="text-slate-400 p-4">Please select a project from the list to begin.</p>';
        return;
    }

    let itemsToRender, title;
    if (context.type === 'project') {
        const project = projects.find(p => p.ProjectID === context.id);
        title = project.ProjectName;
        itemsToRender = tasks.filter(t => t.ProjectID === context.id && t.ParentTaskID === null);
    } else { // context.type === 'task'
        const task = tasks.find(t => t.TaskID === context.id);
        title = task.TaskName;
        itemsToRender = tasks.filter(t => t.ParentTaskID === context.id);
    }
    viewTitleEl.textContent = title;

    switch (currentViewMode) {
        case 'list': renderListView(itemsToRender); break;
        case 'chart': renderChartView(itemsToRender); break;
        case 'kanban': default: renderKanbanView(itemsToRender); break;
    }
}

// --- HIERARCHICAL & VIEW RENDERING ---
function renderProjects() {
    projectListEl.innerHTML = '';
    const currentProjectId = navigationStack.length > 0 ? navigationStack[0].id : null;
    projects.forEach(project => {
        const li = document.createElement('li');
        li.innerHTML = `<a href="#" class="block p-2 rounded-md transition-colors ${currentProjectId === project.ProjectID ? 'bg-cyan-500/20 text-cyan-300' : 'hover:bg-slate-700'}" data-project-id="${project.ProjectID}">${project.ProjectName}</a>`;
        li.addEventListener('click', (e) => { e.preventDefault(); navigationStack = [{ type: 'project', id: project.ProjectID }]; render(); });
        projectListEl.appendChild(li);
    });
}
function renderBreadcrumb() {
    breadcrumbEl.innerHTML = '';
    navigationStack.forEach((item, index) => {
        let name = (item.type === 'project') ? projects.find(p => p.ProjectID === item.id).ProjectName : tasks.find(t => t.TaskID === item.id).TaskName;
        const crumb = document.createElement('span');
        crumb.className = 'cursor-pointer hover:text-cyan-400';
        crumb.textContent = name;
        crumb.addEventListener('click', () => { navigationStack = navigationStack.slice(0, index + 1); render(); });
        breadcrumbEl.appendChild(crumb);
        if (index < navigationStack.length - 1) {
            const separator = document.createElement('span');
            separator.className = 'mx-2';
            separator.textContent = '/';
            breadcrumbEl.appendChild(separator);
        }
    });
}
function renderViewSwitcher() {
    viewSwitcherEl.innerHTML = '';
    ['kanban', 'list', 'chart'].forEach(view => {
        const btn = document.createElement('button');
        btn.className = `view-btn px-3 py-1 rounded capitalize text-sm font-semibold transition-colors ${currentViewMode === view ? 'active' : 'hover:bg-slate-600'}`;
        btn.textContent = view;
        btn.addEventListener('click', () => { currentViewMode = view; render(); });
        viewSwitcherEl.appendChild(btn);
    });
}

// --- MULTI-VIEW RENDERERS ---
function renderKanbanView(tasksToRender) {
    viewContainerEl.innerHTML = `<div id="kanban-board" class="grid grid-flow-col auto-cols-xs md:auto-cols-sm gap-4 h-full"></div>`;
    const kanbanBoardEl = document.getElementById('kanban-board');
    KANBAN_STATUSES.forEach(status => {
        const column = document.createElement('div');
        column.className = 'kanban-column flex flex-col bg-slate-800/50 rounded-lg p-2 min-h-[50vh]';
        column.dataset.status = status;
        column.innerHTML = `<h3 class="font-bold text-slate-300 p-2 mb-2 border-b-2 border-slate-700">${status}</h3><div class="task-container flex-grow space-y-3 overflow-y-auto p-1"></div><button class="quick-add-task-btn p-2 text-slate-400 hover:text-white hover:bg-slate-700 rounded-md mt-2">+ Add task</button>`;
        kanbanBoardEl.appendChild(column);
    });
    tasksToRender.forEach(task => {
        const column = kanbanBoardEl.querySelector(`.kanban-column[data-status="${task.Status}"] .task-container`);
        if (column) column.appendChild(createTaskCard(task));
    });
    addDragAndDropListeners();
}
function renderListView(tasksToRender) {
    let listHtml = `
        <div class="bg-slate-800/50 rounded-lg">
            <div class="grid grid-cols-12 gap-4 p-4 font-bold border-b border-slate-700 text-slate-400 text-sm">
                <div class="col-span-6">Task Name</div>
                <div class="col-span-2">Assignee</div>
                <div class="col-span-2">Due Date</div>
                <div class="col-span-2">Priority</div>
            </div>
            <div id="list-container"></div>
            <button class="quick-add-task-btn p-3 text-slate-400 hover:text-white hover:bg-slate-700 rounded-b-md w-full">+ Add task</button>
        </div>
    `;
    viewContainerEl.innerHTML = listHtml;
    const listContainerEl = document.getElementById('list-container');
    
    if (tasksToRender.length === 0) {
        listContainerEl.innerHTML = '<p class="p-4 text-slate-500">No tasks to display.</p>';
        return;
    }

    tasksToRender.forEach(task => {
        const row = document.createElement('div');
        row.className = 'grid grid-cols-12 gap-4 p-4 border-b border-slate-800 items-center hover:bg-slate-800 cursor-pointer';
        const subtaskIcon = hasSubtasks(task.TaskID) ? `<svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-slate-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h18M3 14h18m-9-4v8m-7 0h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>` : ``;
        row.innerHTML = `
            <div class="col-span-6 font-semibold flex items-center">
                <div class="subtask-link flex-shrink-0 w-8 h-8 flex items-center justify-center -ml-2 rounded-full hover:bg-slate-700">${subtaskIcon}</div>
                <span class="task-link truncate">${task.TaskName}</span>
            </div>
            <div class="col-span-2 text-sm text-slate-400">${findEmployee(task.AssigneeID).EmployeeName}</div>
            <div class="col-span-2 text-sm text-slate-400">${task.DueDate || 'N/A'}</div>
            <div class="col-span-2"><span class="px-2 py-1 text-xs rounded-full font-semibold ${getPriorityStyles(task.Priority)}">${task.Priority}</span></div>
        `;
        row.addEventListener('click', (e) => {
             if (e.target.closest('.subtask-link') && hasSubtasks(task.TaskID)) {
                navigationStack.push({ type: 'task', id: task.TaskID });
                render();
            } else {
                openTaskModal(task.TaskID);
            }
        });
        listContainerEl.appendChild(row);
    });
}
function renderChartView(tasksToRender) {
    const today = new Date();
    const startDate = tasksToRender.length > 0 ? tasksToRender.reduce((min, t) => new Date(t.StartDate) < min ? new Date(t.StartDate) : min, new Date()) : new Date();
    startDate.setDate(startDate.getDate() - 5);

    const endDate = tasksToRender.length > 0 ? tasksToRender.reduce((max, t) => new Date(t.DueDate) > max ? new Date(t.DueDate) : max, new Date(0)) : new Date();
    endDate.setDate(endDate.getDate() + 5);

    const totalDays = Math.max(30, (endDate - startDate) / (1000 * 60 * 60 * 24));
    
    let headerHtml = '';
    for(let i = 0; i <= totalDays; i++) {
        const date = new Date(startDate);
        date.setDate(startDate.getDate() + i);
        headerHtml += `<div class="text-center text-xs p-1 border-r border-slate-700 flex-shrink-0" style="width: 40px;">${date.getMonth()+1}/${date.getDate()}</div>`;
    }

    let rowsHtml = '';
    tasksToRender.forEach((task) => {
        const taskStart = new Date(task.StartDate);
        const taskEnd = new Date(task.DueDate);
        
        if (!task.StartDate || !task.DueDate) return;
        
        const startOffsetDays = Math.max(0, (taskStart - startDate) / (1000 * 60 * 60 * 24));
        const durationDays = Math.max(1, (taskEnd - taskStart) / (1000 * 60 * 60 * 24));
        const startPercent = startOffsetDays / totalDays * 100;
        const widthPercent = durationDays / totalDays * 100;

        rowsHtml += `
            <div class="flex items-center text-sm p-2 border-b border-slate-800">
                <div class="w-48 truncate pr-2">${task.TaskName}</div>
                <div class="flex-grow h-6 bg-slate-700 rounded overflow-hidden">
                    <div class="h-full bg-cyan-600 rounded hover:bg-cyan-500" style="margin-left: ${startPercent}%; width: ${widthPercent}%;" title="${task.TaskName} (${task.StartDate} - ${task.DueDate})"></div>
                </div>
            </div>
        `;
    });

    viewContainerEl.innerHTML = `
        <div class="overflow-x-auto">
            <div class="min-w-max">
                <div class="flex items-center sticky top-0 bg-slate-900">
                    <div class="w-48 font-bold p-2 border-b border-slate-700">Task</div>
                    <div class="flex flex-grow border-b border-slate-700">${headerHtml}</div>
                </div>
                ${rowsHtml}
            </div>
        </div>
    `;
}

// --- TASK CARD & MODALS ---
function createTaskCard(task) {
    const card = document.createElement('div');
    card.className = 'task-card bg-slate-800 p-3 rounded-md shadow-md border border-slate-700 hover:border-cyan-500/50 cursor-pointer transition-all';
    card.dataset.taskId = task.TaskID;
    card.draggable = true;
    const subtaskIcon = hasSubtasks(task.TaskID) ? `<svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-slate-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h18M3 14h18m-9-4v8m-7 0h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>` : '';
    card.innerHTML = `<h4 class="font-semibold text-slate-200">${task.TaskName}</h4><div class="flex justify-between items-center mt-3 text-xs"><span class="text-slate-400">${findEmployee(task.AssigneeID).EmployeeName}</span><div class="flex items-center space-x-2"><div class="subtask-indicator" title="View subtasks">${subtaskIcon}</div><span class="px-2 py-1 rounded-full font-semibold ${getPriorityStyles(task.Priority)}">${task.Priority}</span></div></div>`;
    card.addEventListener('click', (e) => {
        if (e.target.closest('.subtask-indicator') && hasSubtasks(task.TaskID)) {
            navigationStack.push({ type: 'task', id: task.TaskID });
            render();
        } else {
            openTaskModal(task.TaskID);
        }
    });
    return card;
}

function openTaskModal(taskId) {
    const task = tasks.find(t => t.TaskID === taskId);
    if (!task) return;

    modalTaskNameEl.textContent = task.TaskName;
    editTaskBtn.dataset.taskId = taskId;
    deleteTaskBtn.dataset.taskId = taskId;

    const subtasks = tasks.filter(t => t.ParentTaskID === taskId);
    const subtasksHtml = subtasks.length > 0 ? subtasks.map(subtask => `<li class="flex justify-between items-center p-2 rounded-md hover:bg-slate-700/50 cursor-pointer" data-task-id="${subtask.TaskID}"><span>${subtask.TaskName}</span><span class="text-xs px-2 py-1 rounded-full" style="background-color: #47556950;">${subtask.Status}</span></li>`).join('') : '<li>No subtasks.</li>';

    modalContentEl.innerHTML = `
        <div class="space-y-6">
            <div class="flex justify-between items-start">
                <p class="text-slate-300 flex-grow pr-4">${task.Description || 'No description provided.'}</p>
                <span class="text-sm font-bold py-1 px-3 rounded-full ${getPriorityStyles(task.Status === 'Done' ? 'Low' : 'Medium')}" style="background-color: #47556950;">${task.Status}</span>
            </div>
             <div class="grid grid-cols-2 gap-4 text-sm border-t border-b border-slate-700 py-4">
                <div><strong class="text-slate-400 block">Assignee:</strong> ${findEmployee(task.AssigneeID).EmployeeName}</div>
                <div><strong class="text-slate-400 block">Priority:</strong> <span class="px-2 py-1 rounded-full font-semibold ${getPriorityStyles(task.Priority)}">${task.Priority}</span></div>
                <div><strong class="text-slate-400 block">Start Date:</strong> ${task.StartDate || 'Not set'}</div>
                <div><strong class="text-slate-400 block">Due Date:</strong> ${task.DueDate || 'Not set'}</div>
            </div>
            <div>
                <div class="flex justify-between items-center mb-2">
                    <h4 class="font-bold text-lg text-slate-300">Subtasks</h4>
                    <button id="add-subtask-btn" class="flex items-center space-x-1 text-sm bg-slate-700 hover:bg-slate-600 px-3 py-1 rounded-md">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M12 6v6m0 0v6m0-6h6m-6 0H6" /></svg>
                        <span>Add</span>
                    </button>
                </div>
                <ul id="modal-subtask-list" class="space-y-1">${subtasksHtml}</ul>
            </div>
            <!-- History section can be added here if needed -->
        </div>`;
    
    document.getElementById('add-subtask-btn').addEventListener('click', () => openCreateTaskModal({ parentTaskId: taskId }));
    document.getElementById('modal-subtask-list').addEventListener('click', (e) => {
        const targetLi = e.target.closest('li');
        if (targetLi && targetLi.dataset.taskId) {
            closeTaskModal();
            openTaskModal(parseInt(targetLi.dataset.taskId));
        }
    });

    taskModalEl.classList.remove('hidden');
    taskModalEl.classList.add('flex');
}
function closeTaskModal() { taskModalEl.classList.add('hidden'); taskModalEl.classList.remove('flex'); }

function openCreateTaskModal({ parentTaskId = null, editTaskId = null } = {}) {
    const context = navigationStack[navigationStack.length - 1];
    if (!context) { alert("Please select a project first!"); return; }
    
    createTaskForm.reset();
    createTaskForm.dataset.parentTaskId = parentTaskId || '';
    createTaskForm.dataset.editTaskId = editTaskId || '';

    const assigneeSelect = document.getElementById('create-task-assignee');
    assigneeSelect.innerHTML = '';
    employees.forEach(emp => {
        const option = document.createElement('option');
        option.value = emp.EmployeeID;
        option.textContent = emp.EmployeeName;
        assigneeSelect.appendChild(option);
    });

    if (editTaskId) {
        createModalTitleEl.textContent = 'Edit Task';
        const task = tasks.find(t => t.TaskID === editTaskId);
        document.getElementById('create-task-name').value = task.TaskName;
        document.getElementById('create-task-desc').value = task.Description;
        assigneeSelect.value = task.AssigneeID;
        document.getElementById('create-task-priority').value = task.Priority;
    } else {
        createModalTitleEl.textContent = parentTaskId ? 'Create New Subtask' : 'Create New Task';
    }
    // Manually trigger label state for pre-filled values
    document.querySelectorAll('.floating-input').forEach(input => {
        if (input.value) {
            input.classList.remove('placeholder-shown');
        } else {
            input.classList.add('placeholder-shown');
        }
    });

    createTaskModalEl.classList.remove('hidden');
    createTaskModalEl.classList.add('flex');
}
function closeCreateTaskModal() { createTaskModalEl.classList.add('hidden'); createTaskModalEl.classList.remove('flex'); }

function openAddProjectModal() { addProjectForm.reset(); addProjectModalEl.classList.remove('hidden'); addProjectModalEl.classList.add('flex'); }
function closeAddProjectModal() { addProjectModalEl.classList.add('hidden'); addProjectModalEl.classList.remove('flex'); }

// --- EVENT HANDLERS ---
function handleCreateOrUpdateTask(e) {
    e.preventDefault();
    const context = navigationStack[0];
    const editTaskId = createTaskForm.dataset.editTaskId ? parseInt(createTaskForm.dataset.editTaskId) : null;
    
    if (editTaskId) {
        const task = tasks.find(t => t.TaskID === editTaskId);
        task.TaskName = document.getElementById('create-task-name').value;
        task.Description = document.getElementById('create-task-desc').value;
        task.AssigneeID = parseInt(document.getElementById('create-task-assignee').value);
        task.Priority = document.getElementById('create-task-priority').value;
    } else {
        const parentTaskId = createTaskForm.dataset.parentTaskId ? parseInt(createTaskForm.dataset.parentTaskId) : null;
        const newTask = {
            TaskID: getNextTaskId(), ProjectID: context.id,
            TaskName: document.getElementById('create-task-name').value,
            Description: document.getElementById('create-task-desc').value,
            AssigneeID: parseInt(document.getElementById('create-task-assignee').value),
            CreatedBy: 1, ParentTaskID: parentTaskId,
            StartDate: new Date().toISOString().split('T')[0], DueDate: null, Status: 'To Do',
            Priority: document.getElementById('create-task-priority').value,
        };
        tasks.push(newTask);
    }
    closeCreateTaskModal();
    render();
    if(editTaskId) openTaskModal(editTaskId); // Re-open detail modal after edit
}
function handleDeleteTask(taskId) {
    if (!confirm("Are you sure you want to delete this task and all its subtasks? This action cannot be undone.")) return;

    let tasksToDelete = [taskId];
    let i = 0;
    while(i < tasksToDelete.length) {
        const currentTaskId = tasksToDelete[i];
        const subtasksToDelete = tasks.filter(t => t.ParentTaskID === currentTaskId).map(t => t.TaskID);
        tasksToDelete.push(...subtasksToDelete);
        i++;
    }

    tasksToDelete.forEach(id => {
        const index = tasks.findIndex(t => t.TaskID === id);
        if (index > -1) tasks.splice(index, 1);
    });

    closeTaskModal();
    render();
}
function handleCreateProject(e) { 
    e.preventDefault(); 
    const newProjectName = document.getElementById('add-project-name').value; 
    if (!newProjectName) return; 
    const newProject = { ProjectID: getNextProjectId(), ProjectName: newProjectName, OwnerID: 1 }; 
    projects.push(newProject); 
    closeAddProjectModal(); 
    navigationStack = [{ type: 'project', id: newProject.ProjectID }]; 
    render(); 
}
function addDragAndDropListeners() {
    const cards = document.querySelectorAll('.task-card');
    const columns = document.querySelectorAll('.kanban-column');

    cards.forEach(card => {
        card.addEventListener('dragstart', () => {
            draggedTaskId = parseInt(card.dataset.taskId);
            card.classList.add('dragging');
        });
        card.addEventListener('dragend', () => {
            card.classList.remove('dragging');
            draggedTaskId = null;
        });
    });

    columns.forEach(column => {
        column.addEventListener('dragover', e => { e.preventDefault(); column.classList.add('drag-over'); });
        column.addEventListener('dragleave', () => { column.classList.remove('drag-over'); });
        column.addEventListener('drop', e => {
            e.preventDefault();
            column.classList.remove('drag-over');
            const newStatus = column.dataset.status;
            const task = tasks.find(t => t.TaskID === draggedTaskId);
            if (task && task.Status !== newStatus) {
                const oldStatus = task.Status;
                task.Status = newStatus;
                taskProcesses.push({
                    ProcessID: getNextProcessId(),
                    TaskID: draggedTaskId,
                    OldStatus: oldStatus,
                    NewStatus: newStatus,
                    ChangedBy: 1, // Hardcoded current user
                    ChangedDate: new Date().toISOString(),
                });
                render();
            }
        });
    });
}

// --- INITIALIZATION ---
document.addEventListener('DOMContentLoaded', () => {
    modalCloseBtn.addEventListener('click', closeTaskModal);
    createModalCloseBtn.addEventListener('click', closeCreateTaskModal);
    addProjectCloseBtn.addEventListener('click', closeAddProjectModal);
    addProjectBtn.addEventListener('click', openAddProjectModal);
    addProjectForm.addEventListener('submit', handleCreateProject);
    createTaskForm.addEventListener('submit', handleCreateOrUpdateTask);
    
    editTaskBtn.addEventListener('click', (e) => openCreateTaskModal({ editTaskId: parseInt(e.currentTarget.dataset.taskId) }));
    deleteTaskBtn.addEventListener('click', (e) => handleDeleteTask(parseInt(e.currentTarget.dataset.taskId)));

    viewContainerEl.addEventListener('click', e => { if(e.target.closest('.quick-add-task-btn')) openCreateTaskModal(); });
    window.addEventListener('keydown', (e) => { if (e.key === 'Escape') { closeTaskModal(); closeCreateTaskModal(); closeAddProjectModal(); } });

    if (projects.length > 0) navigationStack = [{ type: 'project', id: projects[0].ProjectID }];
    render();
});
