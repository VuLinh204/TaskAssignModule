# Features Documentation

Comprehensive guide to all features in the Task Management Tool.

## 🎯 Core Features

### 1. Project Management

**Create Projects**
- Click the "+" button in the sidebar
- Enter a project name
- Projects appear in the left sidebar
- Click any project to view its tasks

**Navigate Projects**
- Sidebar shows all projects
- Active project is highlighted
- Click to switch between projects

---

### 2. Task Management

**Create Tasks**
- Click "+ Add task" button in any view
- Fill in task details:
  - Task Name (required)
  - Description
  - Assignee
  - Priority (Low/Medium/High)
  - Due Date
  - Status

**Edit Tasks**
- Click any task to open details
- Click the edit icon (pencil) in the modal
- Update any field
- Changes save automatically

**Delete Tasks**
- Open task details
- Click delete icon (trash)
- Confirms before deletion
- Deletes task and all subtasks

---

### 3. Subtask Hierarchy

**Create Subtasks**
- Open a parent task
- Click "+ Add Subtask" in the modal
- Subtasks inherit the parent's project

**Navigate Subtasks**
- Click the grid icon next to any task with subtasks
- Opens a new level showing only subtasks
- Breadcrumb navigation at the top

**Hierarchical Structure**
```
Project
├── Task 1
│   ├── Subtask 1.1
│   └── Subtask 1.2
├── Task 2
└── Task 3
    └── Subtask 3.1
        └── Sub-subtask 3.1.1
```

---

### 4. Multiple Views

#### Kanban View (Default)
- Visual board with status columns
- Drag and drop tasks between statuses
- Quick add task button in each column
- Color-coded priority badges
- Shows assignee avatars

**Statuses:**
- To Do
- In Progress
- Testing
- Done

**Drag & Drop:**
1. Click and hold any task card
2. Drag to desired column
3. Release to update status
4. Status change is logged automatically

#### List View
- Table format with sortable columns
- Columns:
  - Task Name
  - Assignee
  - Due Date
  - Priority
- Click any row to view details
- Better for tasks with lots of metadata

#### Chart View
- Gantt-style timeline
- Visual representation of task durations
- Shows start and end dates
- Color-coded by status
- Quick overview of project timeline

---

### 5. Task Details Modal

**Information Displayed:**
- Task name and description
- Assigned team member
- Priority level with color coding
- Start and due dates
- Current status
- Task tags
- Activity history (status changes)
- List of subtasks

**Actions Available:**
- Edit task
- Delete task
- Add subtask
- View subtask details
- Close modal (ESC key or X button)

---

### 6. Tags & Labels

**What are Tags?**
- Color-coded labels for categorization
- Examples: Bug, Feature, UI, Backend
- Multiple tags per task

**Using Tags:**
- Currently in view-only mode
- Displayed in task cards and details
- Can be extended for filtering

---

### 7. Team Management

**Employees/Assignees**
- Pre-defined team members
- Assign tasks when creating/editing
- See assignee in all views
- Track workload per person

**Current Team Members:**
- Alice (Project Manager)
- Bob (Software Engineer)
- Charlie (Software Engineer)
- Diana (QA Engineer)
- Ethan (UI/UX Designer)

---

### 8. Priority System

**Priority Levels:**
- **High** - Red badge, urgent items
- **Medium** - Yellow badge, normal items
- **Low** - Green badge, when-possible items

**Visual Indicators:**
- Color-coded badges
- Consistent across all views
- Easy to spot high-priority tasks

---

### 9. Activity Tracking

**Status Change History**
- Logs every status update
- Records who made the change
- Timestamp for each change
- Viewable in task details

**Information Tracked:**
- Old status
- New status
- Changed by (user)
- Date and time

---

### 10. Breadcrumb Navigation

**Features:**
- Shows current location in hierarchy
- Click any level to go back
- Updates when drilling into subtasks
- Format: `Project > Task > Subtask`

---

## 🎨 UI Features

### Dark Theme
- Easy on the eyes
- Professional appearance
- Consistent color scheme
- Slate/Cyan palette

### Responsive Design
- Works on desktop, tablet, mobile
- Adaptive layout
- Touch-friendly on mobile
- Collapsible sidebar on small screens

### Floating Labels
- Modern input design
- Labels animate on focus
- Clear indication of filled fields
- Better UX than traditional labels

### Smooth Animations
- Fade-in effects for cards
- Drag animations
- Modal transitions
- Hover states

---

## ⌨️ Keyboard Shortcuts

- **ESC** - Close any open modal
- **Click anywhere outside modal** - Close modal
- Standard browser shortcuts work

---

## 🔄 Data Persistence

**Current Implementation:**
- In-memory storage
- Data resets on page refresh
- Perfect for demo/testing

**Future Enhancement Options:**
1. **localStorage** - Browser-based persistence
2. **Backend API** - Real database
3. **IndexedDB** - Advanced browser storage
4. **Cloud sync** - Multi-device support

---

## 🎯 Use Cases

### Software Development
- Track features and bugs
- Manage sprints
- Monitor QA testing
- Coordinate team work

### Project Management
- Break down large projects
- Assign responsibilities
- Track progress
- Manage deadlines

### Personal Tasks
- Todo lists
- Goal tracking
- Home projects
- Learning objectives

### Team Collaboration
- Shared visibility
- Clear ownership
- Status updates
- Progress tracking

---

## 🚀 Advanced Tips

### Efficient Task Creation
1. Create high-level tasks first
2. Add subtasks for details
3. Use consistent naming
4. Set realistic due dates

### Organization Strategies
- Use tags for categories
- Group related tasks
- Break large tasks into subtasks
- Review and update regularly

### Workflow Optimization
1. Start with "To Do"
2. Move to "In Progress" when working
3. Move to "Testing" for review
4. Complete to "Done"

### Team Best Practices
- Assign tasks clearly
- Set appropriate priorities
- Update status regularly
- Add detailed descriptions
- Use subtasks for clarity

---

## 📊 Data Model

### Task Object Structure
```javascript
{
  TaskID: number,
  ProjectID: number,
  TaskName: string,
  Description: string,
  AssigneeID: number,
  CreatedBy: number,
  ParentTaskID: number | null,
  StartDate: string,
  DueDate: string,
  Status: string,
  Priority: string
}
```

### Project Object Structure
```javascript
{
  ProjectID: number,
  ProjectName: string,
  Description: string,
  OwnerID: number,
  StartDate: string,
  EndDate: string,
  Status: string,
  Priority: string
}
```

---

## 🛠️ Customization

### Adding Custom Statuses
Edit `index.js`:
```javascript
const KANBAN_STATUSES = ['To Do', 'In Progress', 'Testing', 'Done', 'Your Custom Status'];
```

### Changing Colors
Edit `index.css` or Tailwind classes in `index.html`

### Adding More Team Members
Edit `data.js`:
```javascript
export const employees = [
  { EmployeeID: 1, EmployeeName: 'Alice', ... },
  // Add your team members here
];
```

---

## 📝 Notes

- This is a demo/starter application
- No backend required
- Data is not persistent by default
- Fully customizable
- Production-ready architecture
- Easy to extend with real API

---

For technical implementation details, see the code comments in:
- `index.js` - Main application logic
- `data.js` - Data structures and sample data
- `index.html` - UI structure
